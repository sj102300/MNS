#pragma once

#include "JsonParser.h"
#include <vector>
#include <string>

using namespace sm;

class ATS {
public:
    void setAircraftList(const std::vector<AircraftInfo>& list);
    void launchAll();

private:
    std::vector<AircraftInfo> aircrafts_;

    std::string makeCommandString(const AircraftInfo& info);
    void makeCommand(const std::string& command);  // CreateProcess ����
};
